﻿using System;
namespace SprintLibrary
{
	public class ColorModel
	{
		public ColorModel()
		{
		}

		string[] colors =
		{
			"Red",
            "Orange",
            "Yellow",
            "Green",
            "Cyan",
            "Blue",
            "Violet"
        };
	}
}

