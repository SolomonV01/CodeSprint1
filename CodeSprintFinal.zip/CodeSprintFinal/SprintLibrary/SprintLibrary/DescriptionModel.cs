﻿using System;
namespace SprintLibrary
{
	public class DescriptionModel
	{
		public DescriptionModel()
		{
		}

		string[] descriptions = {
			"A color with a frequency between 400-480 terahertz.",
			"A color with a frequency between 480-510 terahertz",
            "A color with a frequency between 510-530 terahertz",
            "A color with a frequency between 530-600 terahertz",
            "A color with a frequency between 600-620 terahertz",
            "A color with a frequency between 620-670 terahertz",
            "A color with a frequency between 670-790 terahertz"
        };
	}
}

