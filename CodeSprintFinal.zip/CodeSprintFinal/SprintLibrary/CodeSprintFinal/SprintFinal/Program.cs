﻿namespace SprintFinal;
class Program
{
    static void Main(string[] args)
    {
        Colors colors = new Colors();
        colors.Start();
    }
}

